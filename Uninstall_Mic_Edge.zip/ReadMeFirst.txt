Hi, this is a program which uninstalls microsoft edge, yes, steps:

1) Run the .exe as administrator
2) The windows defender might tell this as a virus, it's not a virus!! it just tells that because this .exe is not actually registered, it's just a for people who want to do it exe
3) wait and see the stupid microsoft edge uninstall!

also another thing is, do not rename the files, this might make the "Uninstaller" not work!