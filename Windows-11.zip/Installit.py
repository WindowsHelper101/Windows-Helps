import os

print("Installation of windows 11 with no windows installed bloat-ware")
input("Start, press ENTER to start: ")
os.system("powershell wininit")
